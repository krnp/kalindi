<?php $__env->startSection('content'); ?>
<!-- ============================================================== -->
<!-- Bread crumb and right sidebar toggle -->
<!-- ============================================================== -->
<div class="page-breadcrumb">
  <div class="row">
    <div class="col-12 d-flex no-block align-items-center">
      <h4 class="page-title">Cases</h4>
      <div class="ml-auto text-right">
        <nav aria-label="breadcrumb">
          <ol class="breadcrumb">
            <li class="breadcrumb-item"><a href="#">Home</a></li>
            <li class="breadcrumb-item active" aria-current="page">Cases</li>
          </ol>
        </nav>
      </div>
    </div>
  </div>
</div>
<!-- ============================================================== -->
<!-- End Bread crumb and right sidebar toggle -->
<!-- ============================================================== -->
<!-- ============================================================== -->
<!-- Container fluid  -->
<!-- ============================================================== -->
<div class="container-fluid">
  <div class="row">
    <div class="col-12">
      <div class="card">
        <div class="card-body border-bottom">
			<?php if(Session::has('message')): ?>
				<script>
					toastr.options.closeButton = true;
					toastr.options.progressBar = true;
				</script>
				<?php if(Session::get('alerttype')=='success'): ?>
					<script>
						toastr.success('<?php echo e(Session::get('message')); ?>', {timeOut: 10000});
					</script>
				<?php elseif(Session::get('alerttype')=='danger'): ?>
					<script>
						toastr.error('<?php echo e(Session::get('message')); ?>', {timeOut: 10000});
					</script>
				<?php endif; ?>
			<?php endif; ?>
			
          <h4 class="card-title">
		  	<a href="<?php echo e(url('cases/edit/'.$result->id)); ?>"><button type="button" class="btn btn-outline-cyan btn-sm"><i class="far fas fa-edit"></i> Edit</button></a>
			<a href="<?php echo e(url('cases')); ?>">
            	<button type="button" class="btn btn-outline-dark btn-sm float-right"><i class="fas fa-undo"></i> Back</button>
            </a>
		  </h4>
        </div>
        <div class="table-responsive">
          <form class="form-horizontal" action="<?php echo e(url('cases/edit/'.$result->id)); ?>" method="post">
		  <?php echo e(csrf_field()); ?>

            <div class="card-body">
			  <!--<div class="form-group row">
                <label class="col-sm-2 text-right control-label col-form-label">Case Name :</label>
                <div class="col-sm-10">
				  <input type="text" class="form-control" name="case_name" placeholder="Case name here">
                </div>
              </div>
			  <div class="form-group row">
                <label class="col-sm-2 text-right control-label col-form-label">Case Info :</label>
                <div class="col-sm-10">
				  <textarea class="form-control" name="case_info" placeholder="Case info here"></textarea>
                </div>
              </div>-->
              <div class="form-group row">
                <label class="col-sm-2 text-right control-label col-form-label">File No :</label>
                <div class="col-sm-10">
				  	<?php $__currentLoopData = $Courts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $Court): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						<?php if($result->file_court_id==$Court->id): ?> <?php echo e($Court->court_name); ?> <?php endif; ?>
					<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
					/
					<?php echo e($result->file_file_no); ?>

					/
					<?php echo e($result->file_year); ?>

                </div>
              </div>
              <div class="form-group row">
                <label class="col-sm-2 text-right control-label col-form-label">Case No :</label>
                <div class="col-sm-10">
					<?php $__currentLoopData = $Groups; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $Group): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						<?php if($result->case_group_id==$Group->id): ?> <?php echo e($Group->group_name); ?> <?php endif; ?>
					<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
					/
					<?php echo e($result->case_case_no); ?>

					/
					<?php echo e($result->case_year); ?>

                </div>
              </div>
              <div class="form-group row">
                <label class="col-sm-2 text-right control-label col-form-label">Court Name :</label>
                <div class="col-sm-10">
				  <?php $__currentLoopData = $Courts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $Court): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						<?php if($result->court_id==$Court->id): ?> <?php echo e($Court->court_name); ?> <?php endif; ?>
					<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
              </div>
              <div class="form-group row">
                <label class="col-sm-2 text-right control-label col-form-label">Crime No :</label>
                <div class="col-sm-10">
				  <?php echo e($result->crime_no); ?>

                </div>
              </div>
              <div class="form-group row">
                <label class="col-sm-2 text-right control-label col-form-label">Under Section :</label>
                <div class="col-sm-10">
				  <?php echo e($result->under_section); ?>

                </div>
              </div>
              <!--<div class="form-group row">
                <label class="col-sm-2 text-right control-label col-form-label">Bill Date :</label>
                <div class="col-sm-10">
				  <?php echo e(date('d-m-Y',$result->bill_date)); ?>

                </div>
              </div>
              <div class="form-group row">
                <label class="col-sm-2 text-right control-label col-form-label">Paid Date :</label>
                <div class="col-sm-10">
				  <?php echo e(date('d-m-Y',$result->paid_date)); ?>

                </div>
              </div>-->
              <div class="form-group row">
                <label class="col-sm-2 text-right control-label col-form-label">Filing Date :</label>
                <div class="col-sm-10">
				  <?php echo e(date('d-m-Y',$result->filing_date)); ?>

                </div>
              </div>
              <div class="form-group row">
                <label class="col-sm-2 text-right control-label col-form-label">Hearing Date :</label>
                <div class="col-sm-10">
				  <?php echo e(date('d-m-Y',$result->hearing_date)); ?>

                </div>
              </div>
              <div class="form-group row">
                <label class="col-sm-2 text-right control-label col-form-label">Stage :</label>
                <div class="col-sm-10">
				  <?php $__currentLoopData = $CaseStage; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $Stage): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						<?php if($result->stage_id==$Stage->id): ?> <?php echo e($Stage->case_stage_name); ?> <?php endif; ?>
					<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
              </div>
			  <div class="form-group row">
                <label class="col-sm-2 text-right control-label col-form-label">Appearing For :</label>
                <div class="col-sm-10">
					<?php if($result->appearing_for=='Petitioner'): ?> Petitioner <?php endif; ?>
					<?php if($result->appearing_for=='Respondent'): ?> Respondent <?php endif; ?>
                </div>
              </div>
              <div class="form-group row">
                <label class="col-sm-2 text-right control-label col-form-label">Party Details :</label>
                <div class="col-sm-10">
					<div class="row">
						<ol id="PartyDetailsResults" style="padding:0 10px; width:100%">
							<?php $__currentLoopData = $Parties; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $Party): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
								<li style="padding:10px; margin:10px 0; border:1px solid #c3bdbd;background: #f2f2f2; width:100%">
								  <table width="100%" border="0">
									<tr>
									  <td><strong>Party Name:</strong> <?php echo e($Party->party_name); ?> <?php echo e($Party->belong_to); ?> <?php echo e($Party->belong_to_name); ?> <strong>Age: </strong><?php echo e($Party->age); ?> <strong>Address: </strong><?php echo e($Party->address1); ?> <?php echo e($Party->address2); ?> <?php echo e($Party->city); ?> <?php echo e($Party->state); ?> <?php echo e($Party->pincode); ?> <?php echo e($Party->country); ?> </td>
									</tr>
									<tr>
									  <td><strong>Mobile: </strong><?php echo e($Party->mobile); ?> <strong>Email: </strong><?php echo e($Party->email); ?></td>
									</tr>
								  </table>
								</li>

							<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
						</ol>
						
					</div>
                </div>
              </div>
			  <div class="form-group row">
                <label class="col-sm-2 text-right control-label col-form-label">Party Representative :</label>
                <div class="col-sm-10">
					<div class="row">
						<ol id="PartyDetailsResultsR" style="padding:0 10px; width:100%">
							<?php $__currentLoopData = $PartiesR; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $Party): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
								<li style="padding:10px; margin:10px 0; border:1px solid #c3bdbd;background: #f2f2f2; width:100%">
								  <table width="100%" border="0">
									<tr>
									  <td><strong>Representative Name:</strong> <?php echo e($Party->party_name); ?> <?php echo e($Party->belong_to); ?> <?php echo e($Party->belong_to_name); ?> <strong>Age: </strong><?php echo e($Party->age); ?> <strong>Address: </strong><?php echo e($Party->address1); ?> <?php echo e($Party->address2); ?> <?php echo e($Party->city); ?> <?php echo e($Party->state); ?> <?php echo e($Party->pincode); ?> <?php echo e($Party->country); ?> </td>
									</tr>
									<tr>
									  <td><strong>Mobile: </strong><?php echo e($Party->mobile); ?> <strong>Email: </strong><?php echo e($Party->email); ?></td>
									</tr>
								  </table>
								</li>

							<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
						</ol>
					</div>
                </div>
              </div>
              
              
            </div>
            
          </form>
        </div>
      </div>
    </div>
  </div>
</div>



<script src="<?php echo e(asset('assets/libs/select2/dist/js/select2.full.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/libs/select2/dist/js/select2.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/libs/bootstrap-datepicker/dist/js/bootstrap-datepicker.min.js')); ?>"></script>
<script type="text/javascript">
	//***********************************//
	// For select 2
	//***********************************//
	jQuery(".select2").select2();

	jQuery('.bill_date, .paid_date, .filing_date, .hearing_date').datepicker({ format:'dd-mm-yyyy', autoclose:true });
	jQuery('.next_hearing_date').datepicker({ format:'dd-mm-yyyy', autoclose:true });
	jQuery('.file_year').datepicker({ format:'yyyy', autoclose:true, viewMode: "years", minViewMode: "years", endDate: '+0d', });
	jQuery('.case_year').datepicker({ format:'yyyy', autoclose:true, viewMode: "years", minViewMode: "years", endDate: '+0d', });
</script>
<script type="text/javascript">
	jQuery(document).ready(function(){
		jQuery('#add_party').click(function(){
			jQuery('#PartyDetailsResults').append('<li style="padding:10px; margin:10px 0; border:1px solid #c3bdbd;background: #f2f2f2;"><table width="100%" border="0"><tr><td><input type="text" class="form-control" name="party_name[]" value="" placeholder="Party Name"></td><td><select class="form-control" name="belong_to[]"><option value="S/O"> S/O </option><option value="D/O"> D/O </option></select></td><td><input type="text" class="form-control" name="belong_to_name[]" value="" placeholder="Name"></td><td><input type="text" class="form-control" name="age[]" value="" placeholder="Age"></td><td rowspan="3" valign="middle"><a href="javascript:;" class="deletePD text-danger" title="Delete"><i class="fas fa-trash-alt"></i></a></td></tr><tr><td><input type="text" class="form-control" name="address1[]" value="" placeholder="Address 1"></td><td><input type="text" class="form-control" name="address2[]" value="" placeholder="Address 2"></td><td><input type="text" class="form-control" name="city[]" value="" placeholder="City"></td>  <td><input type="text" class="form-control" name="state[]" value="" placeholder="State"></td>  </tr><tr><td><input type="text" class="form-control" name="pincode[]" value="" placeholder="Pin Code"></td><td><input type="text" class="form-control" name="country[]" value="India" disable="disable" placeholder="Country"></td><td><input type="text" class="form-control" name="mobile[]" value="" placeholder="Mobile"></td><td><input type="text" class="form-control" name="email[]" value="" placeholder="Email"></td></tr></table></li>');
		});
		jQuery(document).delegate('.deletePD', 'click', function(){
			jQuery(this).parents('li').remove();
		});
		
		jQuery('#add_representative').click(function(){
			jQuery('#PartyDetailsResultsR').append('<li style="padding:10px; margin:10px 0; border:1px solid #c3bdbd;background: #f2f2f2;"><table width="100%" border="0"><tr><td><input type="text" class="form-control" name="r_party_name[]" value="" placeholder="Representative Name"></td><td><select class="form-control" name="r_belong_to[]"><option value="S/O"> S/O </option><option value="D/O"> D/O </option></select></td><td><input type="text" class="form-control" name="r_belong_to_name[]" value="" placeholder="Name"></td><td><input type="text" class="form-control" name="r_age[]" value="" placeholder="Age"></td><td rowspan="3" valign="middle"><a href="javascript:;" class="deleterepresentative text-danger" title="Delete"><i class="fas fa-trash-alt"></i></a></td></tr><tr><td><input type="text" class="form-control" name="r_address1[]" value="" placeholder="Address 1"></td><td><input type="text" class="form-control" name="r_address2[]" value="" placeholder="Address 2"></td><td><input type="text" class="form-control" name="r_city[]" value="" placeholder="City"></td>  <td><input type="text" class="form-control" name="r_state[]" value="" placeholder="State"></td></tr><tr><td><input type="text" class="form-control" name="r_pincode[]" value="" placeholder="Pin Code"></td><td><input type="text" class="form-control" name="r_country[]" value="India" disable="disable" placeholder="Country"></td><td><input type="text" class="form-control" name="r_mobile[]" value="" placeholder="Mobile"></td><td><input type="text" class="form-control" name="r_email[]" value="" placeholder="Email"></td></tr></table></li>');
		});
		jQuery(document).delegate('.deleterepresentative', 'click', function(){
			jQuery(this).parents('li').remove();
		});
	})
</script>
<?php $__env->stopSection(); ?> 
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>