<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<!-- CSRF Token -->
<meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
<title><?php echo e(config('app.name', 'Laravel')); ?></title>
<!-- Custom CSS -->
<link rel="stylesheet" type="text/css" href="<?php echo e(asset('assets/libs/select2/dist/css/select2.min.css')); ?>">
<link href="<?php echo e(asset('assets/libs/flot/css/float-chart.css')); ?>" rel="stylesheet">
<!-- Custom CSS -->
<link href="<?php echo e(asset('dist/css/style.min.css')); ?>" rel="stylesheet">
<link rel="stylesheet" type="text/css" href="<?php echo e(asset('assets/extra-libs/multicheck/multicheck.css')); ?>">
<link href="<?php echo e(asset('assets/libs/toastr/build/toastr.min.css')); ?>" rel="stylesheet">
<link rel="stylesheet" type="text/css" href="<?php echo e(asset('assets/libs/bootstrap-datepicker/dist/css/bootstrap-datepicker.min.css')); ?>">

<!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
<!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
<!--[if lt IE 9]>
    <script src="<?php echo e(asset('dist/js/html5shiv.js')); ?>"></script>
    <script src="<?php echo e(asset('dist/js/respond.min.js')); ?>"></script>
	<![endif]-->

<script src="<?php echo e(asset('assets/libs/jquery/dist/jquery.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/libs/toastr/build/toastr.min.js')); ?>"></script>
<style>
.datepicker-dropdown {
	z-index: 99 !important;
}
</style>
</head>
<body>
<!-- ============================================================== -->
<!-- Preloader - style you can find in spinners.css -->
<!-- ============================================================== -->
<div class="preloader">
  <div class="lds-ripple">
    <div class="lds-pos"></div>
    <div class="lds-pos"></div>
  </div>
</div>
<!-- ============================================================== -->
<!-- Main wrapper - style you can find in pages.scss -->
<!-- ============================================================== -->
<div id="main-wrapper">
  <!-- ============================================================== -->
  <!-- Topbar header - style you can find in pages.scss -->
  <!-- ============================================================== -->
  <header class="topbar" data-navbarbg="skin5">
    <nav class="navbar top-navbar navbar-expand-md navbar-dark">
      <div class="navbar-header" data-logobg="skin5">
        <!-- This is for the sidebar toggle which is visible on mobile only -->
        <a class="nav-toggler waves-effect waves-light d-block d-md-none" href="javascript:void(0)"><i class="ti-menu ti-close"></i></a>
        <!-- ============================================================== -->
        <!-- Logo -->
        <!-- ============================================================== -->
        <a class="navbar-brand" href="<?php echo e(url('home')); ?>">
        <!-- Logo icon -->
        <b class="logo-icon p-l-10">
        <!--You can put here icon as well // <i class="wi wi-sunset"></i> //-->
        <!-- Dark Logo icon -->
        <i class="fas fa-balance-scale" style="font-size:26px"></i> </b>
        <!--End Logo icon -->
        <!-- Logo text -->
        <span class="logo-text" style="font-size:24px">
        <!-- dark Logo text -->
        LegalAxis </span>
        <!-- Logo icon -->
        <!-- <b class="logo-icon"> -->
        <!--You can put here icon as well // <i class="wi wi-sunset"></i> //-->
        <!-- Dark Logo icon -->
        <!-- <img src="../../assets/images/logo-text.png" alt="homepage" class="light-logo" /> -->
        <!-- </b> -->
        <!--End Logo icon -->
        </a>
        <!-- ============================================================== -->
        <!-- End Logo -->
        <!-- ============================================================== -->
        <!-- ============================================================== -->
        <!-- Toggle which is visible on mobile only -->
        <!-- ============================================================== -->
        <a class="topbartoggler d-block d-md-none waves-effect waves-light" href="javascript:void(0)" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation"><i class="ti-more"></i></a> </div>
      <!-- ============================================================== -->
      <!-- End Logo -->
      <!-- ============================================================== -->
      <div class="navbar-collapse collapse" id="navbarSupportedContent" data-navbarbg="skin5">
        <!-- ============================================================== -->
        <!-- toggle and nav items -->
        <!-- ============================================================== -->
        <ul class="navbar-nav float-left mr-auto">
          <li class="nav-item d-none d-md-block"><a class="nav-link sidebartoggler waves-effect waves-light" href="javascript:void(0)" data-sidebartype="mini-sidebar"><i class="mdi mdi-menu font-24"></i></a></li>
          <!-- ============================================================== -->
          <!-- create new -->
          <!-- ============================================================== -->
          <!--<li class="nav-item dropdown"> <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false"> <span class="d-none d-md-block">Create New <i class="fa fa-angle-down"></i></span> <span class="d-block d-md-none"><i class="fa fa-plus"></i></span> </a>
            <div class="dropdown-menu" aria-labelledby="navbarDropdown"> <a class="dropdown-item" href="#">Action</a> <a class="dropdown-item" href="#">Another action</a>
              <div class="dropdown-divider"></div>
              <a class="dropdown-item" href="#">Something else here</a> </div>
          </li>-->
          <!-- ============================================================== -->
          <!-- Search -->
          <!-- ============================================================== -->
          <!--<li class="nav-item search-box"> <a class="nav-link waves-effect waves-dark" href="javascript:void(0)"><i class="ti-search"></i></a>
            <form class="app-search position-absolute">
              <input type="text" class="form-control" placeholder="Search &amp; enter">
              <a class="srh-btn"><i class="ti-close"></i></a>
            </form>
          </li>-->
        </ul>
        <!-- ============================================================== -->
        <!-- Right side toggle and nav items -->
        <!-- ============================================================== -->
        <ul class="navbar-nav float-right">
          <!-- ============================================================== -->
          <!-- Comment -->
          <!-- ============================================================== -->
          <!--<li class="nav-item dropdown"> <a class="nav-link dropdown-toggle waves-effect waves-dark" href="" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false"> <i class="mdi mdi-bell font-24"></i> </a>
            <div class="dropdown-menu" aria-labelledby="navbarDropdown"> <a class="dropdown-item" href="#">Action</a> <a class="dropdown-item" href="#">Another action</a>
              <div class="dropdown-divider"></div>
              <a class="dropdown-item" href="#">Something else here</a> </div>
          </li>-->
          <!-- ============================================================== -->
          <!-- End Comment -->
          <!-- ============================================================== -->
          <!-- ============================================================== -->
          <!-- Messages -->
          <!-- ============================================================== -->
          <?php /*?><li class="nav-item dropdown"> <a class="nav-link dropdown-toggle waves-effect waves-dark" href="" id="2" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false"> <i class="font-24 mdi mdi-comment-processing"></i> </a>
            <div class="dropdown-menu dropdown-menu-right mailbox animated bounceInDown" aria-labelledby="2">
              <ul class="list-style-none">
                <li>
                  <div class="">
                    <!-- Message -->
                    <a href="javascript:void(0)" class="link border-top">
                    <div class="d-flex no-block align-items-center p-10"> <span class="btn btn-success btn-circle"><i class="ti-calendar"></i></span>
                      <div class="m-l-10">
                        <h5 class="m-b-0">Event today</h5>
                        <span class="mail-desc">Just a reminder that event</span> </div>
                    </div>
                    </a>
                    <!-- Message -->
                    <a href="javascript:void(0)" class="link border-top">
                    <div class="d-flex no-block align-items-center p-10"> <span class="btn btn-info btn-circle"><i class="ti-settings"></i></span>
                      <div class="m-l-10">
                        <h5 class="m-b-0">Settings</h5>
                        <span class="mail-desc">You can customize this template</span> </div>
                    </div>
                    </a>
                    <!-- Message -->
                    <a href="javascript:void(0)" class="link border-top">
                    <div class="d-flex no-block align-items-center p-10"> <span class="btn btn-primary btn-circle"><i class="ti-user"></i></span>
                      <div class="m-l-10">
                        <h5 class="m-b-0">Pavan kumar</h5>
                        <span class="mail-desc">Just see the my admin!</span> </div>
                    </div>
                    </a>
                    <!-- Message -->
                    <a href="javascript:void(0)" class="link border-top">
                    <div class="d-flex no-block align-items-center p-10"> <span class="btn btn-danger btn-circle"><i class="fa fa-link"></i></span>
                      <div class="m-l-10">
                        <h5 class="m-b-0">Luanch Admin</h5>
                        <span class="mail-desc">Just see the my new admin!</span> </div>
                    </div>
                    </a> </div>
                </li>
              </ul>
            </div>
          </li><?php */?>
          <!-- ============================================================== -->
          <!-- End Messages -->
          <!-- ============================================================== -->
          <!-- ============================================================== -->
          <!-- User profile and search -->
          <!-- ============================================================== -->
          <li class="nav-item dropdown"> <a class="nav-link dropdown-toggle text-muted waves-effect waves-dark pro-pic" href="" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false"><i class="fas fa-user" style="font-size:26px"></i></a>
            <div class="dropdown-menu dropdown-menu-right user-dd animated"> <a class="dropdown-item" href="javascript:void(0)"><i class="ti-user m-r-5 m-l-5"></i> My Profile</a> <a class="dropdown-item" href="javascript:void(0)"><i class="ti-wallet m-r-5 m-l-5"></i> My Balance</a> <a class="dropdown-item" href="javascript:void(0)"><i class="ti-email m-r-5 m-l-5"></i> Inbox</a>
              <div class="dropdown-divider"></div>
              <a class="dropdown-item" href="javascript:void(0)"><i class="ti-settings m-r-5 m-l-5"></i> Account Setting</a>
              <div class="dropdown-divider"></div>
              <a class="dropdown-item" href="javascript:void(0)" onClick="event.preventDefault();document.getElementById('logout-form').submit();"><i class="fa fa-power-off m-r-5 m-l-5"></i> Logout</a>
			  <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;">
					<?php echo e(csrf_field()); ?>

				</form>
              <div class="dropdown-divider"></div>
              <div class="p-l-30 p-10"><a href="javascript:void(0)" class="btn btn-sm btn-success btn-rounded">View Profile</a></div>
            </div>
          </li>
          <!-- ============================================================== -->
          <!-- User profile and search -->
          <!-- ============================================================== -->
        </ul>
      </div>
    </nav>
  </header>
  <!-- ============================================================== -->
  <!-- End Topbar header -->
  <!-- ============================================================== -->
  <!-- ============================================================== -->
  <!-- Left Sidebar - style you can find in sidebar.scss  -->
  <!-- ============================================================== -->
  <aside class="left-sidebar" data-sidebarbg="skin5">
    <!-- Sidebar scroll-->
    <div class="scroll-sidebar">
      <!-- Sidebar navigation-->
      <nav class="sidebar-nav">
        <ul id="sidebarnav" class="p-t-30">
          <li class="sidebar-item"> <a class="sidebar-link waves-effect waves-dark sidebar-link" href="<?php echo e(url('groups')); ?>" aria-expanded="false"><i class="fas fa-users"></i><span class="hide-menu">Groups</span></a></li>
          <li class="sidebar-item"> <a class="sidebar-link waves-effect waves-dark sidebar-link" href="<?php echo e(url('courts')); ?>" aria-expanded="false"><i class="fas fa-gavel"></i><span class="hide-menu">Courts</span></a></li>
          <li class="sidebar-item"> <a class="sidebar-link waves-effect waves-dark sidebar-link" href="<?php echo e(url('case-status')); ?>" aria-expanded="false"><i class="fas fa-check"></i><span class="hide-menu">Case Status</span></a></li>
          <li class="sidebar-item"> <a class="sidebar-link waves-effect waves-dark sidebar-link" href="<?php echo e(url('case-stages')); ?>" aria-expanded="false"><i class="fas fa-level-up-alt"></i><span class="hide-menu">Case Stages</span></a></li>
          <li class="sidebar-item"> <a class="sidebar-link waves-effect waves-dark sidebar-link" href="<?php echo e(url('cases')); ?>" aria-expanded="false"><i class="fas fa-suitcase"></i><span class="hide-menu">Cases</span></a></li>
          
        </ul>
      </nav>
      <!-- End Sidebar navigation -->
    </div>
    <!-- End Sidebar scroll-->
  </aside>
  <!-- ============================================================== -->
  <!-- End Left Sidebar - style you can find in sidebar.scss  -->
  <!-- ============================================================== -->
  <!-- ============================================================== -->
  <!-- Page wrapper  -->
  <!-- ============================================================== -->
  <div class="page-wrapper">
    
	<?php echo $__env->yieldContent('content'); ?>
    <!-- ============================================================== -->
    <!-- End Container fluid  -->
    <!-- ============================================================== -->
    <!-- ============================================================== -->
    <!-- footer -->
    <!-- ============================================================== -->
    <footer class="footer text-center"> copyright &copy; <?php echo e(date('Y')); ?>. <a href="https://AeonAxiSoftech.com">Aeonaxis Softech (P) LTD</a>, All right reserved. </footer>
    <!-- ============================================================== -->
    <!-- End footer -->
    <!-- ============================================================== -->
  </div>
  <!-- ============================================================== -->
  <!-- End Page wrapper  -->
  <!-- ============================================================== -->
</div>

<!-- Bootstrap tether Core JavaScript -->
<script src="<?php echo e(asset('assets/libs/popper.js/dist/umd/popper.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/libs/bootstrap/dist/js/bootstrap.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/libs/perfect-scrollbar/dist/perfect-scrollbar.jquery.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/extra-libs/sparkline/sparkline.js')); ?>"></script>
<!--Wave Effects -->
<script src="<?php echo e(asset('dist/js/waves.js')); ?>"></script>
<!--Menu sidebar -->
<script src="<?php echo e(asset('dist/js/sidebarmenu.js')); ?>"></script>
<!--Custom JavaScript -->
<script src="<?php echo e(asset('dist/js/custom.min.js')); ?>"></script>
<!--This page JavaScript -->
<!-- <script src="<?php echo e(asset('dist/js/pages/dashboards/dashboard1.js')); ?>"></script> -->
<!-- Charts js Files -->
<script src="<?php echo e(asset('assets/libs/flot/excanvas.js')); ?>"></script>
<script src="<?php echo e(asset('assets/libs/flot/jquery.flot.js')); ?>"></script>
<script src="<?php echo e(asset('assets/libs/flot/jquery.flot.pie.js')); ?>"></script>
<script src="<?php echo e(asset('assets/libs/flot/jquery.flot.time.js')); ?>"></script>
<script src="<?php echo e(asset('assets/libs/flot/jquery.flot.stack.js')); ?>"></script>
<script src="<?php echo e(asset('assets/libs/flot/jquery.flot.crosshair.js')); ?>"></script>
<script src="<?php echo e(asset('assets/libs/flot.tooltip/js/jquery.flot.tooltip.min.js')); ?>"></script>
<script src="<?php echo e(asset('dist/js/pages/chart/chart-page-init.js')); ?>"></script>
<script src="<?php echo e(asset('assets/extra-libs/multicheck/datatable-checkbox-init.js')); ?>"></script>
<script src="<?php echo e(asset('assets/extra-libs/multicheck/jquery.multicheck.js')); ?>"></script>


</body>
</html>
