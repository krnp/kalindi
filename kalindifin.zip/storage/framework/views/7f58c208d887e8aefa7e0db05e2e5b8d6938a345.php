<?php $__env->startSection('content'); ?>
<!-- ============================================================== -->
<!-- Bread crumb and right sidebar toggle -->
<!-- ============================================================== -->
<div class="page-breadcrumb">
  <div class="row">
    <div class="col-12 d-flex no-block align-items-center">
      <h4 class="page-title">Cases</h4>
      <div class="ml-auto text-right">
        <nav aria-label="breadcrumb">
          <ol class="breadcrumb">
            <li class="breadcrumb-item"><a href="#">Home</a></li>
            <li class="breadcrumb-item active" aria-current="page">Cases</li>
          </ol>
        </nav>
      </div>
    </div>
  </div>
</div>
<!-- ============================================================== -->
<!-- End Bread crumb and right sidebar toggle -->
<!-- ============================================================== -->
<!-- ============================================================== -->
<!-- Container fluid  -->
<!-- ============================================================== -->
<div class="container-fluid">
  <div class="row">
    <div class="col-12">
      
      <div class="card">
        <div class="card-body">
			<?php if(Session::has('message')): ?>
				<script>
					toastr.options.closeButton = true;
					toastr.options.progressBar = true;
				</script>
				<?php if(Session::get('alerttype')=='success'): ?>
					<script>
						toastr.success('<?php echo e(Session::get('message')); ?>', {timeOut: 10000});
					</script>
				<?php elseif(Session::get('alerttype')=='danger'): ?>
					<script>
						toastr.error('<?php echo e(Session::get('message')); ?>', {timeOut: 10000});
					</script>
				<?php endif; ?>
			<?php endif; ?>
								
			<button type="button" class="btn btn-outline-danger btn-sm"><i class="fas fa-trash-alt"></i> Delete</button>

			<a href="<?php echo e(url('cases/add')); ?>"><button type="button" class="btn btn-outline-dark btn-sm float-right"><i class="far fas fa-pencil-alt"></i> Add New</button></a>
        </div>
        <div class="table-responsive">
          <table class="table">
            <thead class="thead-light">
              <tr>
                <th> <label class="customcheckbox m-b-20">
                  <input type="checkbox" id="mainCheckbox">
                  <span class="checkmark"></span> </label>
                </th>
                <th scope="col">File No</th>
                <th scope="col">Case No</th>
                <th scope="col">Total Party</th>
                <th scope="col">Total Representative</th>
                <th scope="col">Actions</th>
              </tr>
            </thead>
            <tbody class="customtable">
			<?php $__currentLoopData = $result; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $res): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <tr>
                <th> <label class="customcheckbox">
                  <input type="checkbox" class="listCheckbox" name="checked[]" value="<?php echo e($res->id); ?>">
                  <span class="checkmark"></span> </label>
                </th>
                <td><?php echo e($res->FileCourt->court_name); ?>/<?php echo e($res->file_file_no); ?>/<?php echo e($res->file_year); ?></td>
                <td><?php echo e($res->FileGroup->group_name); ?>/<?php echo e($res->case_case_no); ?>/<?php echo e($res->case_year); ?></td>
                <td><?php echo e(count(json_decode(json_encode($res->CaseParties)))); ?></td>
                <td><?php echo e(count(json_decode(json_encode($res->CasePartiesR)))); ?></td>
                <td>
					<a href="<?php echo e(url('cases/bill/'.$res->id)); ?>"><button type="button" class="btn btn-outline-info btn-sm"><i class="far fas fa-rupee"></i> Bill</button></a>
					<a href="<?php echo e(url('cases/view/'.$res->id)); ?>"><button type="button" class="btn btn-outline-success btn-sm"><i class="far fas fa-eye"></i> View</button></a>
					<a href="<?php echo e(url('cases/edit/'.$res->id)); ?>"><button type="button" class="btn btn-outline-cyan btn-sm"><i class="far fas fa-edit"></i> Edit</button></a>
					<button type="button" class="btn btn-outline-danger btn-sm" data-toggle="modal" data-target="#Modal<?php echo e($res->id); ?>"><i class="fas fa-trash-alt"></i> Delete</button>
					<div class="modal fade" id="Modal<?php echo e($res->id); ?>" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true ">
						<div class="modal-dialog" role="document ">
							<div class="modal-content">
								<div class="modal-header">
									<h5 class="modal-title" id="exampleModalLabel"><?php echo e($res->court_name); ?></h5>
									<button type="button" class="close" data-dismiss="modal" aria-label="Close">
										<span aria-hidden="true ">&times;</span>
									</button>
								</div>
								<div class="modal-body">
									Do you want to delete this ?
								</div>
								<div class="modal-footer">
									<a href="<?php echo e(url('cases/delete/'.$res->id)); ?>"><button type="button" class="btn btn-danger float-left">Yes</button></a>
									<button type="button" class="btn btn-secondary" data-dismiss="modal">No</button>
								</div>
							</div>
						</div>
					</div>
				</td>
              </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
          </table>
        </div>
		<div class="border-top">
			<div class="card-body">
			  <?php if($result): ?>
				<?php echo e($result->links()); ?>

			  <?php endif; ?>
			</div>
        </div>
      </div>
      
      
    </div>
  </div>
</div>
<?php $__env->stopSection(); ?> 
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>