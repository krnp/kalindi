<?php $__env->startSection('customcss'); ?>
<style>

legend{

width:auto!important;

padding: 0px!important;

border: none!important;

margin-bottom:0px;		



}

fieldset {

    padding: 22px;

    margin: 0 2px;

    border: 2px solid silver!important;

}

label{

    text-align: left!important;

}

.innerlegend{

padding:1% 0;

}

.innerlegend fieldset{

    padding: 12px;

    margin: 0 1px;

    border: 2px dotted greenyellow!important;

}

.fileinput{

padding-bottom:2%;

}

</style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="col-md-12 col-sm-12 col-xs-12"> <?php if(session('status')): ?>
  <div class="alert alert-success alert-dismissible fade in" role="alert">
    <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">×</span> </button>
    <?php echo e(session('status')); ?> </div>
  <?php endif; ?>
  
  <div class="x_panel">
                  <div class="x_title">
                    <h2><?php echo e($result->borrower_name); ?> <small>Profile Details</small></h2>
                    <div class="clearfix"></div>
                  </div>
                  <div class="x_content">
                    <div class="col-md-4 col-sm-4 col-xs-12 profile_left">
                      <div class="profile_img">
                        <div id="crop-avatar">
                          <!-- Current avatar -->
						  <?php if($result->borrower_photo): ?>
                          	<img class="img-responsive avatar-view" style="width:200px; height:200px; object-fit:cover; border:5px solid darkgrey; border-radius:100%" src="<?php echo e(URL::to('photo/'.$result->borrower_photo)); ?>" alt="<?php echo e($result->borrower_name); ?>" title="<?php echo e($result->borrower_name); ?>">
						  <?php else: ?>
						  	<img class="img-responsive avatar-view" style="width:200px; height:200px; object-fit:cover; border:5px solid darkgrey; border-radius:100%" src="<?php echo e(URL::to('images/not-available.png')); ?>" alt="<?php echo e($result->borrower_name); ?>" title="<?php echo e($result->borrower_name); ?>">
						  <?php endif; ?>
                        </div>
                      </div>
						
						<p>&nbsp;</p>
                      	<table class="data table table-striped no-margin" border="1">
							<thead>
								  <tr><td colspan="2"><h3>Borrower Details</h3></td></tr>
							  </thead>
                              <tbody>
                                <tr>
                                  <td align="right" width="50%"><strong>Pan Number:</strong></td>
                                  <td><?php echo e($result->borrower_pan); ?></td>
                                </tr>
								<tr>
                                  <td align="right"><strong>AAdhar Number:</strong></td>
                                  <td><?php echo e($result->borrower_aadhar); ?></td>
                                </tr>
                                <tr>
                                  <td align="right"><strong>Age:</strong></td>
                                  <td><?php echo e($result->borrower_age); ?></td>
                                </tr>
                                <tr>
                                  <td align="right"><strong><?php echo e($result->borrower_care_of); ?>:</strong></td>
                                  <td><?php echo e($result->borrower_care_of_name); ?></td>
                                </tr>
                                <tr>
                                  <td align="right"><strong>Present Address:</strong></td>
                                  <td><?php echo e($result->borrower_present_addr); ?></td>
                                </tr>
                                <tr>
                                  <td align="right"><strong>Land Mark:</strong></td>
                                  <td><?php echo e($result->borrower_present_addr_landmark); ?></td>
                                </tr>
                                <tr>
                                  <td align="right"><strong>Permanent Home Address:</strong></td>
                                  <td><?php echo e($result->borrower_parmanent_addr); ?></td>
                                </tr>
                                <tr>
                                  <td align="right"><strong>Residence:</strong></td>
                                  <td><?php echo e($result->borrower_present_addr_type); ?></td>
                                </tr>
                                <tr>
                                  <td align="right"><strong>Occupation:</strong></td>
                                  <td><?php echo e($result->borrower_occupation); ?></td>
                                </tr>
                                <tr>
                                  <td align="right"><strong>Designation:</strong></td>
                                  <td><?php echo e($result->borrower_designation); ?></td>
                                </tr>
                                <tr>
                                  <td align="right"><strong>Name & Office Address/Plase of Business:</strong></td>
                                  <td><?php echo e($result->borrower_office_addr); ?></td>
                                </tr>
                                <tr>
                                  <td align="right"><strong>Telephone Office:</strong></td>
                                  <td><?php echo e($result->borrower_phone_office); ?></td>
                                </tr>
                                <tr>
                                  <td align="right"><strong>Telephone Residence:</strong></td>
                                  <td><?php echo e($result->borrower_phone_residence); ?></td>
                                </tr>
                                <tr>
                                  <td align="right"><strong>Mobile:</strong></td>
                                  <td><?php echo e($result->borrower_phone_mobile); ?></td>
                                </tr>
                                <tr>
                                  <td align="right"><strong>Is the Post Permanent or Temporary:</strong></td>
                                  <td><?php echo e($result->borrower_job_type); ?></td>
                                </tr>
                                <tr>
                                  <td align="right"><strong>Whether your occupation is subject to transfer:</strong></td>
                                  <td><?php echo e($result->borrower_occupation_transfer); ?></td>
                                </tr>
                                <tr>
                                  <td align="right"><strong>Gross Family Income:</strong></td>
                                  <td><?php echo e($result->borrower_family_income); ?></td>
                                </tr>
                              </tbody>
                            </table>
                     
                    </div>
                    <div class="col-md-8 col-sm-8 col-xs-12">
						

                      <div class="" role="tabpanel" data-example-id="togglable-tabs">
                        <ul id="myTab" class="nav nav-tabs bar_tabs" role="tablist">
						  <li role="presentation" class="active"><a href="#LoanDetails" role="tab" id="profile-tab4" data-toggle="tab" aria-expanded="true">Loan Details</a></li>
                          <li role="presentation" class=""><a href="#References" id="home-tab" role="tab" data-toggle="tab" aria-expanded="false">References</a></li>
                          <li role="presentation" class=""><a href="#Co-Borrower" role="tab" id="profile-tab" data-toggle="tab" aria-expanded="false">Co-Borrower</a></li>
                          <li role="presentation" class=""><a href="#Guarantor" role="tab" id="profile-tab2" data-toggle="tab" aria-expanded="false">Guarantor</a></li>
						  <li role="presentation" class=""><a href="#Documents" role="tab" id="profile-tab3" data-toggle="tab" aria-expanded="false">Documents</a></li>
                        </ul>
                        <div id="myTabContent" class="tab-content">
                          <div role="tabpanel" class="tab-pane fade active in" id="LoanDetails" aria-labelledby="profile-tab3">
                            <table class="data table table-striped no-margin">
							  <thead>
								  <tr><td colspan="2"><h4>Loan Details:</h4></td></tr>
							  </thead>
							  <tbody>
								<tr>
								  <td align="right" width="300"><strong>Case Number:</strong></td>
								  <td><?php echo e($result->loan_ag_caseno); ?></td>
								</tr>
								<tr>
								  <td align="right" width="300"><strong>Loan A/C No:</strong></td>
								  <td><?php echo e($result->loan_ac_no); ?></td>
								</tr>
								<tr>
								  <td align="right" width="300"><strong>Invoice Value:</strong></td>
								  <td><?php echo e($result->invoice_value); ?></td>
								</tr>
								<tr>
								  <td align="right" width="300"><strong>Down Payment:</strong></td>
								  <td><?php echo e($result->down_payment); ?></td>
								</tr>
								<tr>
								  <td align="right" width="300"><strong>Loan Amount:</strong></td>
								  <td><?php echo e($result->loan_amount); ?></td>
								</tr>
								<tr>
								  <td align="right" width="300"><strong>Interest@:</strong></td>
								  <td><?php echo e($result->loan_interest); ?></td>
								</tr>
								<tr>
								  <td align="right" width="300"><strong>For (in months):</strong></td>
								  <td><?php echo e($result->loan_for_month); ?></td>
								</tr>
								<tr>
								  <td align="right" width="300"><strong>Loan Date:</strong></td>
								  <td><?php echo e($result->loan_ag_date); ?></td>
								</tr>
								<?php if($result->loanProduct): ?>
								<tr>
								  <td align="right" width="300"><strong>Product:</strong></td>
								  <td><?php echo e($result->loanProduct->name); ?></td>
								</tr>
								<?php endif; ?>
							  </tbody>
							</table>
							
							<table class="data table table-striped no-margin">
							  <thead>
								  <tr><td colspan="2"><h4>Dealer Details:</h4></td></tr>
							  </thead>
							  <tbody>
							<?php if($result->loanDealers): ?>
								<tr>
								  <td align="right" width="300"><strong>Pan Number:</strong></td>
								  <td><?php echo e($result->loanDealers->pan); ?></td>
								</tr>
								<tr>
								  <td align="right" width="300"><strong> AAdhar Number :</strong></td>
								  <td><?php echo e($result->loanDealers->aadhar); ?></td>
								</tr>
								<tr>
								  <td align="right" width="300"><strong>Name:</strong></td>
								  <td><?php echo e($result->loanDealers->name); ?></td>
								</tr>
								<tr>
								  <td align="right" width="300"><strong>Email:</strong></td>
								  <td><?php echo e($result->loanDealers->email); ?></td>
								</tr>
								<tr>
								  <td align="right" width="300"><strong>Phone:</strong></td>
								  <td><?php echo e($result->loanDealers->phone); ?></td>
								</tr>
								<tr>
								  <td align="right" width="300"><strong>Fax:</strong></td>
								  <td><?php echo e($result->loanDealers->fax); ?></td>
								</tr>
								<tr>
								  <td align="right" width="300"><strong>Address:</strong></td>
								  <td><?php echo e($result->loanDealers->addr); ?></td>
								</tr>
								
							  </tbody>
							<?php endif; ?>
							</table>
							
							<table class="data table table-striped no-margin">
							  <thead>
								  <tr><td colspan="2"><h4>Surveyor Details:</h4></td></tr>
							  </thead>
							  <tbody>
							<?php if($result->locanSurveyor): ?>
								<tr>
								  <td align="right" width="300"><strong>Pan Number:</strong></td>
								  <td><?php echo e($result->locanSurveyor->pan); ?></td>
								</tr>
								<tr>
								  <td align="right" width="300"><strong> AAdhar Number :</strong></td>
								  <td><?php echo e($result->locanSurveyor->aadhar); ?></td>
								</tr>
								<tr>
								  <td align="right" width="300"><strong>Name:</strong></td>
								  <td><?php echo e($result->locanSurveyor->name); ?></td>
								</tr>
								<tr>
								  <td align="right" width="300"><strong>Email:</strong></td>
								  <td><?php echo e($result->locanSurveyor->email); ?></td>
								</tr>
								<tr>
								  <td align="right" width="300"><strong>Phone:</strong></td>
								  <td><?php echo e($result->locanSurveyor->phone); ?></td>
								</tr>
								<tr>
								  <td align="right" width="300"><strong>Address:</strong></td>
								  <td><?php echo e($result->locanSurveyor->address); ?></td>
								</tr>
							<?php endif; ?>
							  </tbody>
							</table>
							
							<table class="data table table-striped no-margin">
							  <thead>
								  <tr><td colspan="2"><h4>Field Excutive Details:</h4></td></tr>
							  </thead>
							  <tbody>
							<?php if($result->loanFieldExecutive): ?>
								<tr>
								  <td align="right" width="300"><strong>Pan Number:</strong></td>
								  <td><?php echo e($result->loanFieldExecutive->pan); ?></td>
								</tr>
								<tr>
								  <td align="right" width="300"><strong> AAdhar Number :</strong></td>
								  <td><?php echo e($result->loanFieldExecutive->aadhar); ?></td>
								</tr>
								<tr>
								  <td align="right" width="300"><strong>Name:</strong></td>
								  <td><?php echo e($result->loanFieldExecutive->name); ?></td>
								</tr>
								<tr>
								  <td align="right" width="300"><strong>Email:</strong></td>
								  <td><?php echo e($result->loanFieldExecutive->email); ?></td>
								</tr>
								<tr>
								  <td align="right" width="300"><strong>Phone:</strong></td>
								  <td><?php echo e($result->loanFieldExecutive->phone); ?></td>
								</tr>
								<tr>
								  <td align="right" width="300"><strong>Address:</strong></td>
								  <td><?php echo e($result->loanFieldExecutive->address); ?></td>
								</tr>
							<?php endif; ?>
							  </tbody>
							</table>
                          </div>
						  
						  <div role="tabpanel" class="tab-pane fade " id="References" aria-labelledby="home-tab">
                            <table class="table table-striped">
							  <thead>
								<tr>
								  <th>#</th>
								  <th>Name</th>
								  <th>Relationship</th>
								  <th>Address</th>
								  <th>Telephone Office</th>
								  <th>Telephone Residence</th>
								  <th>Mobile</th>
								</tr>
							  </thead>
							  <?php if($result->LoansReferences): ?>
							  <tbody>
								<tr>
								  <th scope="row">1</th>
								  <td><?php echo e($result->LoansReferences->borrower_reference_1_name); ?></td>
								  <td><?php echo e($result->LoansReferences->borrower_reference_1_relation); ?></td>
								  <td><?php echo e($result->LoansReferences->borrower_reference_1_addr); ?></td>
								  <td><?php echo e($result->LoansReferences->borrower_reference_1_phone_office); ?></td>
								  <td><?php echo e($result->LoansReferences->borrower_reference_1_phone_residence); ?></td>
								  <td><?php echo e($result->LoansReferences->borrower_reference_1_phone_mobile); ?></td>
								</tr>
								<tr>
								  <th scope="row">2</th>
								  <td><?php echo e($result->LoansReferences->borrower_reference_2_name); ?></td>
								  <td><?php echo e($result->LoansReferences->borrower_reference_2_relation); ?></td>
								  <td><?php echo e($result->LoansReferences->borrower_reference_2_addr); ?></td>
								  <td><?php echo e($result->LoansReferences->borrower_reference_2_phone_office); ?></td>
								  <td><?php echo e($result->LoansReferences->borrower_reference_2_phone_residence); ?></td>
								  <td><?php echo e($result->LoansReferences->borrower_reference_2_phone_mobile); ?></td>
								</tr>
							  </tbody>
							  <?php endif; ?>
							</table>

                          </div>
                          <div role="tabpanel" class="tab-pane fade" id="Co-Borrower" aria-labelledby="profile-tab">
							<?php if($result->LoansCoBorrowers): ?>
                            <table class="data table table-striped no-margin">
                              <tbody>
                                <tr>
                                  <td align="right" width="300"><strong>Name of Co-Borrower:</strong></td>
                                  <td><?php echo e($result->LoansCoBorrowers->co_borrower_name); ?></td>
                                </tr>
                                <tr>
                                  <td align="right" width="300"><strong>Pan Number:</strong></td>
                                  <td><?php echo e($result->LoansCoBorrowers->co_borrower_pan); ?></td>
                                </tr>
                                <tr>
                                  <td align="right" width="300"><strong>Aadhar:</strong></td>
                                  <td><?php echo e($result->LoansCoBorrowers->co_borrower_aadhar); ?></td>
                                </tr>
                                <tr>
                                  <td align="right" width="300"><strong>Age:</strong></td>
                                  <td><?php echo e($result->LoansCoBorrowers->co_borrower_age); ?></td>
                                </tr>
                                <tr>
                                  <td align="right" width="300"><strong><?php echo e($result->LoansCoBorrowers->co_borrower_care_of); ?>:</strong></td>
                                  <td><?php echo e($result->LoansCoBorrowers->co_borrower_care_of_name); ?></td>
                                </tr>
                                <tr>
                                  <td align="right" width="300"><strong>Present Address:</strong></td>
                                  <td><?php echo e($result->LoansCoBorrowers->co_borrower_present_addr); ?></td>
                                </tr>
                                <tr>
                                  <td align="right" width="300"><strong>Land Mark:</strong></td>
                                  <td><?php echo e($result->LoansCoBorrowers->co_borrower_present_addr_landmark); ?></td>
                                </tr>
                                <tr>
                                  <td align="right" width="300"><strong>Permanent Home Address:</strong></td>
                                  <td><?php echo e($result->LoansCoBorrowers->co_borrower_parmanent_addr); ?></td>
                                </tr>
                                <tr>
                                  <td align="right" width="300"><strong>Residence:</strong></td>
                                  <td><?php echo e($result->LoansCoBorrowers->co_borrower_present_addr_type); ?></td>
                                </tr>
                                <tr>
                                  <td align="right" width="300"><strong>Occupation:</strong></td>
                                  <td><?php echo e($result->LoansCoBorrowers->co_borrower_occupation); ?></td>
                                </tr>
                                <tr>
                                  <td align="right" width="300"><strong>Designation:</strong></td>
                                  <td><?php echo e($result->LoansCoBorrowers->co_borrower_designation); ?></td>
                                </tr>
                                <tr>
                                  <td align="right" width="300"><strong>Name & Office Address/Plase of Business:</strong></td>
                                  <td><?php echo e($result->LoansCoBorrowers->co_borrower_office_addr); ?></td>
                                </tr>
                                <tr>
                                  <td align="right" width="300"><strong>Telephone Office:</strong></td>
                                  <td><?php echo e($result->LoansCoBorrowers->co_borrower_phone_office); ?></td>
                                </tr>
                                <tr>
                                  <td align="right" width="300"><strong>Telephone Residence:</strong></td>
                                  <td><?php echo e($result->LoansCoBorrowers->co_borrower_phone_residence); ?></td>
                                </tr>
                                <tr>
                                  <td align="right" width="300"><strong>Mobile:</strong></td>
                                  <td><?php echo e($result->LoansCoBorrowers->co_borrower_phone_mobile); ?></td>
                                </tr>
                              </tbody>
                            </table>
                            <?php endif; ?>

                          </div>
                          <div role="tabpanel" class="tab-pane fade" id="Guarantor" aria-labelledby="profile-tab">
                            <?php if($result->LoansGuarantors): ?>
                            <table class="data table table-striped no-margin">
                              <tbody>
                                <tr>
                                  <td align="right" width="300"><strong>Name of Guarantor:</strong></td>
                                  <td><?php echo e($result->LoansGuarantors->guarantor_name); ?></td>
                                </tr>
                                <tr>
                                  <td align="right" width="300"><strong>Pan Number:</strong></td>
                                  <td><?php echo e($result->LoansGuarantors->guarantor_pan); ?></td>
                                </tr>
                                <tr>
                                  <td align="right" width="300"><strong>Aadhar:</strong></td>
                                  <td><?php echo e($result->LoansGuarantors->guarantor_aadhar); ?></td>
                                </tr>
                                <tr>
                                  <td align="right" width="300"><strong>Age:</strong></td>
                                  <td><?php echo e($result->LoansGuarantors->guarantor_age); ?></td>
                                </tr>
                                <tr>
                                  <td align="right" width="300"><strong><?php echo e($result->LoansGuarantors->guarantor_care_of); ?>:</strong></td>
                                  <td><?php echo e($result->LoansGuarantors->guarantor_care_of_name); ?></td>
                                </tr>
                                <tr>
                                  <td align="right" width="300"><strong>Present Address:</strong></td>
                                  <td><?php echo e($result->LoansGuarantors->guarantor_present_addr); ?></td>
                                </tr>
                                <tr>
                                  <td align="right" width="300"><strong>Land Mark:</strong></td>
                                  <td><?php echo e($result->LoansGuarantors->guarantor_present_addr_landmark); ?></td>
                                </tr>
                                <tr>
                                  <td align="right" width="300"><strong>Permanent Home Address:</strong></td>
                                  <td><?php echo e($result->LoansGuarantors->guarantor_parmanent_addr); ?></td>
                                </tr>
                                <tr>
                                  <td align="right" width="300"><strong>Residence:</strong></td>
                                  <td><?php echo e($result->LoansGuarantors->guarantor_present_addr_type); ?></td>
                                </tr>
                                <tr>
                                  <td align="right" width="300"><strong>Occupation:</strong></td>
                                  <td><?php echo e($result->LoansGuarantors->guarantor_occupation); ?></td>
                                </tr>
                                <tr>
                                  <td align="right" width="300"><strong>Designation:</strong></td>
                                  <td><?php echo e($result->LoansGuarantors->guarantor_designation); ?></td>
                                </tr>
                                <tr>
                                  <td align="right" width="300"><strong>Name & Office Address/Plase of Business:</strong></td>
                                  <td><?php echo e($result->LoansGuarantors->guarantor_office_addr); ?></td>
                                </tr>
                                <tr>
                                  <td align="right" width="300"><strong>Telephone Office:</strong></td>
                                  <td><?php echo e($result->LoansGuarantors->guarantor_phone_office); ?></td>
                                </tr>
                                <tr>
                                  <td align="right" width="300"><strong>Telephone Residence:</strong></td>
                                  <td><?php echo e($result->LoansGuarantors->guarantor_phone_residence); ?></td>
                                </tr>
                                <tr>
                                  <td align="right" width="300"><strong>Mobile:</strong></td>
                                  <td><?php echo e($result->LoansGuarantors->guarantor_phone_mobile); ?></td>
                                </tr>
								<tr>
                                  <td align="right" width="300"><strong>Is the Post Permanent or Temporary:</strong></td>
                                  <td><?php echo e($result->LoansGuarantors->guarantor_job_type); ?></td>
                                </tr>
                                <tr>
                                  <td align="right" width="300"><strong>Whether your occupation is subject to transfer:</strong></td>
                                  <td><?php echo e($result->LoansGuarantors->guarantor_occupation_transfer); ?></td>
                                </tr>
                                <tr>
                                  <td align="right" width="300"><strong>Gross Family Income:</strong></td>
                                  <td><?php echo e($result->LoansGuarantors->guarantor_family_income); ?></td>
                                </tr>
                              </tbody>
                            </table>
                            <?php endif; ?>
                          </div>
						  <div role="tabpanel" class="tab-pane fade" id="Documents" aria-labelledby="profile-tab3">
                            <p>aaaaaaaaaaa</p>
                          </div>
						  
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
</div>
<?php $__env->stopSection(); ?> 

<?php $__env->startSection('script'); ?>
<script type="text/javascript">
	$('.cal').Zebra_DatePicker();
	$(document).ready(function() {
		$(".select2").select2();
	});
</script>
<?php $__env->stopSection(); ?> 
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>