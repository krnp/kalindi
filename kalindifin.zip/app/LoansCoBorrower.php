<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class LoansCoBorrower extends Model
{
    //
}
