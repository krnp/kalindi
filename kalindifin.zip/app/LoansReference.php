<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class LoansReference extends Model
{
    //
}
