loan_ag_name
loan_ag_address
loan_ag_caseno
loan_ag_product
loan_ag_dealer
loan_ag_date
loan_app_name
loan_app_product
loan_app_invoice
loan_app_down_payment
loan_app_loan_account
loan_app_loan_amount
loan_app_month
loan_app_interest
loan_app_loandate
loan_app_formonth
first_loanapp_name
first_loanapp_age
first_loanapp_parent
first_loanapp_presesnt_res
first_loanapp_landmark
first_loanapp_per_homeaddr
first_loanapp_homeaddr_type
first_loanapp_occupation
first_loanapp_designation
first_loanapp_nameoffice_addr
first_loanapp_office
first_loanapp_residence
first_loanapp_mobile
first_loanapp_postpermant
first_loanapp_your_occupation
first_loanapp_gross_income
first_loanapp_votercard
first_loanapp_salarycerticate
first_loanapp_refname
first_loanapp_relation
first_loanapp_addr
first_loanapp_tel
first_loanapp_ref2name
first_loanapp_relation2
first_loanapp_address2
first_loanapp_tel2
second_app_coborrower_name
second_app_age
second_app_applicant_relation
second_app_parent
second_app_presentresi
second_app_landmark
second_app_peraddr
second_app_peraddr_type
second_app_occupation
second_app_designation
third_app_coborr_name
third_app_age
third_app_applicantrel
third_app_parent
third_app_present_resid
third_app_landmark
third_app_perhomeaddr
third_app_home_type
third_app_occupation
third_app_designation
third_app_nameoffice_addr
third_app_office
third_app_residence
third_app_mobile
third_app_postpermannt
third_app_your_occupation
third_app_gross_income
third_app_votercard
third_app_bankdetail
third_app_salary_certificate
finalag_agrment_made
finalag_date
finalag_kalindifirst
finalag_borrowname
finalag_gauranter
finalag_loanpurchaseof
pronote_rs
pronote_date
pronote_ondemand
pronote_parent
pronote_rsidentof
pronote_coborrower
pronote_co_parent
pronote_co_residentof
pronote_co_guarantor
pronote_co_guarantor_parent
pronote_co_guarantor_resident
pronote_someofrupee
pronote_interest
pronote_date2
pronote_place