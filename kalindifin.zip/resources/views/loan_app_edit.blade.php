@extends('layouts.app')

@section('customcss')
<style>
legend{
	width:auto!important;
	padding: 0 5px!important;
	border: none!important;
	margin-bottom:0px;		
}
fieldset {
    padding: 22px;
    margin: 0 2px;
    border: 2px solid silver!important;
	background: #fbfbfb;
}
label{
    text-align: left!important;
}

.innerlegend{
	padding:1% 0;
}
.innerlegend fieldset{
    padding: 12px;
    margin: 0 1px;
    border: 2px dotted greenyellow!important;
}
.fileinput{
	padding-bottom:2%;
}
</style>
@endsection

@section('content')
<div class="col-md-12 col-sm-12 col-xs-12"> @if (session('status'))
  <div class="alert alert-success alert-dismissible fade in" role="alert">
    <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">×</span> </button>
    {{ session('status') }} </div>
  @endif
  <div class="x_panel">
    <div class="x_title">
      <h2>Loan Application</h2>
      <ul class="nav navbar-right panel_toolbox">
        <li><a href="{{ url('loan-application') }}" class="green"><i class="fa fa-reply green"></i> <span class="green">Back</span></a></li>
      </ul>
      <div class="clearfix"></div>
    </div>
    <div class="x_content"> <br>
      <form class="form-horizontal" method="POST"

         action="{{ url('loan-application/edit',array($result->id)) }}">
        {{ csrf_field() }}
        <div style="padding: 3% 0;">
          <fieldset>
			  <legend>Loan Agreement</legend>
			  <div class="row">
				<div class="col-md-6">
				  <div class="row">
					<div class="col-md-12">
					  <label class="control-label"> case No. <span class="required">*</span></label>
					</div>
					<div class="col-md-12">
					  <input type="text" id="loan_ag_caseno" name="loan_ag_caseno" value="{{$result->loan_ag_caseno}}" class="form-control">
					</div>
				  </div>
				</div>
				<div class="col-md-6">
				  <div class="row">
					<div class="col-md-12">
					  <label class="control-label"> Product <span class="required">*</span></label>
					</div>
					<div class="col-md-12">
					  <select name="loan_ag_product" class="form-control select2">
						<option value="">-- Select Product --</option>
						@foreach($products as $res)
							<option value="{{$res->id}}" @if($result->loan_ag_product==$res->id) selected="selected" @endif>{{$res->name}}</option>
						@endforeach
					  </select>
					</div>
				  </div>
				</div>
			  </div>
			  <div class="row">
				<div class="col-md-6">
				  <div class="row">
					<div class="col-md-12">
					  <label class="control-label"> Dealer <span class="required">*</span></label>
					</div>
					<div class="col-md-12">
					  <select name="loan_ag_dealer" class="form-control select2">
						<option value="">-- Select Product --</option>
						@foreach($dealers as $res)
							<option value="{{$res->id}}" @if($result->loan_ag_dealer==$res->id) selected="selected" @endif>{{$res->name}}</option>
						@endforeach
					  </select>
					</div>
				  </div>
				</div>
				<div class="col-md-6">
				  <div class="row">
					<div class="col-md-12">
					  <label class="control-label"> Date <span class="required">*</span></label>
					</div>
					<div class="col-md-12">
					  <input type="text" id="loan_ag_date" name="loan_ag_date"  class="form-control cal" value="{{date('Y-m-d',$result->loan_ag_date)}}" >
					</div>
				  </div>
				</div>
			  </div>
          </fieldset>
		  <p>&nbsp;</p>
		  <fieldset>
			  <legend>Loan Application</legend>
			  <div class="row">
				<div class="col-md-4">
				  <div class="row">
					<div class="col-md-12">
					  <label class="control-label">Invoice Value<span class="required">*</span></label>
					</div>
					<div class="col-md-12">
					  <input type="text" id="invoice_value" name="invoice_value" value="{{$result->invoice_value}}" class="form-control">
					</div>
				  </div>
				</div>
				<div class="col-md-4">
				  <div class="row">
					<div class="col-md-12">
					  <label class="control-label"> Down Payment <span class="required">*</span></label>
					</div>
					<div class="col-md-12">
					  <input type="text" id="down_payment" name="down_payment" value="{{$result->down_payment}}" class="form-control">
					</div>
				  </div>
				</div>
				<div class="col-md-4">
				  <div class="row">
					<div class="col-md-12">
					  <label class="control-label"> Loan A/C No. <span class="required">*</span></label>
					</div>
					<div class="col-md-12">
					  <input type="text" id="loan_ac_no" name="loan_ac_no" value="{{$result->loan_ac_no}}" class="form-control">
					</div>
				  </div>
				</div>
			  </div>
			  <div class="row">
				<div class="col-md-4">
				  <div class="row">
					<div class="col-md-12">
					  <label class="control-label"> Loan Amount <span class="required">*</span></label>
					</div>
					<div class="col-md-12">
					  <input type="text" id="loan_amount" name="loan_amount" value="{{$result->loan_amount}}" class="form-control">
					</div>
				  </div>
				</div>
				<div class="col-md-4">
				  <div class="row">
					<div class="col-md-12">
					  <label class="control-label"> For (in months) <span class="required">*</span></label>
					</div>
					<div class="col-md-12">
					  <input type="text" id="loan_for_month" name="loan_for_month" value="{{$result->loan_for_month}}" class="form-control">
					</div>
				  </div>
				</div>
				<div class="col-md-4">
				  <div class="row">
					<div class="col-md-12">
					  <label class="control-label"> Interest@ <span class="required">*</span></label>
					</div>
					<div class="col-md-12">
					  <input type="text" id="loan_interest" name="loan_interest" value="{{$result->loan_interest}}" class="form-control">
					</div>
				  </div>
				</div>
			  </div>
          </fieldset>
		  <p>&nbsp;</p>
		  <fieldset>
			  <legend>Applicant Details</legend>
			  <div class="row">
				<div class="col-md-4">
				  <div class="row">
					<div class="col-md-12">
					  <label class="control-label">Name of Borrower<span class="required">*</span></label>
					</div>
					<div class="col-md-12">
					  <input type="text" id="borrower_name" name="borrower_name" value="{{$result->borrower_name}}" class="form-control">
					</div>
				  </div>
				</div>
				<div class="col-md-2">
				  <div class="row">
					<div class="col-md-12">
					  <label class="control-label">Age <span class="required">*</span></label>
					</div>
					<div class="col-md-12">
					  <input type="text" id="borrower_age" name="borrower_age" value="{{$result->borrower_age}}" class="form-control">
					</div>
				  </div>
				</div>
				<div class="col-md-3">
				  <div class="row">
					<div class="col-md-12">
					  <label class="control-label">Father's / Husband Name Shri<span class="required">*</span></label>
					</div>
					<div class="col-md-12">
					  <select id="borrower_care_of" name="borrower_care_of" class="form-control select2">
						<option value="Father" @if($result->borrower_care_of=='Father') selected="selected" @endif >Father</option>
						<option value="Husband" @if($result->borrower_care_of=='Husband') selected="selected" @endif >Husband</option>
					  </select>
					</div>
				  </div>
				</div>
				<div class="col-md-3">
				  <div class="row">
					<div class="col-md-12">
					  <label class="control-label">&nbsp;</label>
					</div>
					<div class="col-md-12">
					  <input type="text" id="borrower_care_of_name" name="borrower_care_of_name" value="{{$result->borrower_care_of_name}}" class="form-control">
					</div>
				  </div>
				</div>
			  </div>
			  <div class="row">
				<div class="col-md-6">
				  <div class="row">
					<div class="col-md-12">
					  <label class="control-label">Present Address <span class="required">*</span></label>
					</div>
					<div class="col-md-12">
					  <textarea name="borrower_present_addr" id="borrower_present_addr" class="form-control">{{ $result->borrower_present_addr}} </textarea>
					</div>
				  </div>
				</div>
				<div class="col-md-6">
				  <div class="row">
					<div class="col-md-12">
					  <label class="control-label">Land Mark <span class="required">*</span></label>
					</div>
					<div class="col-md-12">
					  <textarea name="borrower_present_addr_ladmark" id="borrower_present_addr_ladmark" class="form-control">{{ $result->borrower_present_addr_ladmark}} </textarea>
					</div>
				  </div>
				</div>
			  </div>
			  <div class="row">
				<div class="col-md-6">
				  <div class="row">
					<div class="col-md-12">
					  <label class="control-label">Permanent Home Address <span class="required">*</span></label>
					</div>
					<div class="col-md-12">
					  <textarea name="borrower_parmanent_addr" id="borrower_parmanent_addr" class="form-control">{{ $result->borrower_parmanent_addr}} </textarea>
					</div>
				  </div>
				</div>
				<div class="col-md-6">
				  <div class="row">
					<div class="col-md-12">
					  <label class="control-label">Residence <span class="required">*</span></label>
					</div>
					<div class="col-md-12">
						<div class="row">
							<div class="col-md-6">
								Own <input type="radio" name="borrower_present_addr_type" value="Own">
							</div>
							<div class="col-md-6">
								Rental <input type="radio" name="borrower_present_addr_type" value="Rental">
							</div>
						</div>
					    <div class="row">
							<div class="col-md-6">
								Parent/Spouse <input type="radio" name="borrower_present_addr_type" value="Parent/Spouse" >
							</div>
							<div class="col-md-6">
								Employer Leased <input type="radio" name="borrower_present_addr_type" value="Employer Leased">
							</div>
						</div>
					</div>
				  </div>
				</div>
			  </div>
			  <div class="row">
				<div class="col-md-6">
				  <div class="row">
					<div class="col-md-12">
					  <label class="control-label">Occupation <span class="required">*</span></label>
					</div>
					<div class="col-md-12">
					  <input type="text" id="borrower_occupation" name="borrower_occupation" value="{{$result->borrower_occupation}}" class="form-control">
					</div>
				  </div>
				  <div class="row">
					<div class="col-md-12">
					  <label class="control-label">Designation <span class="required">*</span></label>
					</div>
					<div class="col-md-12">
					  <input type="text" id="borrower_designation" name="borrower_designation" value="{{$result->borrower_designation}}" class="form-control">
					</div>
				  </div>
				</div>
				<div class="col-md-6">
				  <div class="row">
					<div class="col-md-12">
					  <label class="control-label">Name & Office Address/Plase of Business <span class="required">*</span></label>
					</div>
					<div class="col-md-12">
					  <textarea name="borrower_office_addr" id="borrower_office_addr" class="form-control">{{ $result->borrower_office_addr}} </textarea>
					</div>
				  </div>
				</div>
			  </div>
			  <div class="row">
			    <div class="col-md-12">
			    	<label class="control-label">Telephone No. <span class="required">*</span></label>
				</div>
				<div class="col-md-4">
				  <div class="row">
					<div class="col-md-12">
					  <label class="control-label">Office <span class="required">*</span></label>
					</div>
					<div class="col-md-12">
					  <input type="text" id="borrower_phone_office" name="borrower_phone_office" value="{{$result->borrower_phone_office}}" class="form-control">
					</div>
				  </div>
				</div>
				<div class="col-md-4">
				  <div class="row">
					<div class="col-md-12">
					  <label class="control-label">Residence <span class="required">*</span></label>
					</div>
					<div class="col-md-12">
					  <input type="text" id="borrower_phone_residence" name="borrower_phone_residence" value="{{$result->borrower_phone_residence}}" class="form-control">
					</div>
				  </div>
				</div>
				<div class="col-md-4">
				  <div class="row">
					<div class="col-md-12">
					  <label class="control-label">Mobile <span class="required">*</span></label>
					</div>
					<div class="col-md-12">
					  <input type="text" id="borrower_phone_mobile" name="borrower_phone_mobile" value="{{$result->borrower_phone_mobile}}" class="form-control">
					</div>
				  </div>
				</div>
			  </div>
			  <div class="row">
				<div class="col-md-4">
				  <div class="row">
					<div class="col-md-12">
					  <label class="control-label">Is the Post Permanent or Temporary</label>
					</div>
					<div class="col-md-12">
					  <select id="borrower_job_type" name="borrower_job_type" class="form-control select2">
						<option value="Permanent" @if($result->borrower_job_type=='Father') selected="selected" @endif >Permanent</option>
						<option value="Temporary" @if($result->borrower_job_type=='Temporary') selected="selected" @endif >Temporary</option>
					  </select>
					</div>
				  </div>
				</div>
				<div class="col-md-4">
				  <div class="row">
					<div class="col-md-12">
					  <label class="control-label">Whether your occupation is subject to transfer</label>
					</div>
					<div class="col-md-12">
					  <input type="text" id="borrower_occupation_transfer" name="borrower_occupation_transfer" value="{{$result->borrower_occupation_transfer}}" class="form-control">
					</div>
				  </div>
				</div>
				<div class="col-md-4">
				  <div class="row">
					<div class="col-md-12">
					  <label class="control-label">Gross Family Income</label>
					</div>
					<div class="col-md-12">
					  <input type="text" id="borrower_family_income" name="borrower_family_income" value="{{$result->borrower_family_income}}" class="form-control">
					</div>
				  </div>
				</div>
			  </div>
			  <div class="innerlegend">
            	<fieldset>
				<legend>Attach Photocopy</legend>
				<div class="row">
				  <div class="col-md-4">
					<div class="row">
					  <div class="col-md-12 fileinput">
						<label class="control-label">Identity Details</label>
					  </div>
					  <div class="col-md-12">
						<select id="borrower_identity" name="borrower_identity" class="form-control select2">
							<option value="Voter Card" @if($result->borrower_identity=='Voter Card') selected="selected" @endif >Voter Card</option>
							<option value="Ration Card" @if($result->borrower_identity=='Ration Card') selected="selected" @endif >Ration Card</option>
							<option value="Electricity Bill" @if($result->borrower_identity=='Electricity Bill') selected="selected" @endif >Electricity Bill</option>
							<option value="Water Tax Receipt" @if($result->borrower_identity=='Water Tax Receipt') selected="selected" @endif >Water Tax Receipt</option>
						  </select>
					  </div>
					  <div class="col-md-12">
						<input type="file" id="borrower_identity_file" name="borrower_identity_file" value="{{$result->borrower_identity_file}}" >
					  </div>
					</div>
				  </div>
				  <div class="col-md-4">
					<div class="row">
					  <div class="col-md-12 fileinput">
						<label class="control-label"> Bank Detail</label>
					  </div>
					  <div class="col-md-12">
						<select id="borrower_bankdetail" name="borrower_bankdetail" class="form-control select2">
							<option value="Photocopy of Latest Bank Statement" @if($result->borrower_bankdetail=='Photocopy of Latest Bank Statement') selected="selected" @endif >Photocopy of Latest Bank Statement</option>
							<option value="First Page & Updated Entries of Last 6 Months" @if($result->borrower_bankdetail=='First Page & Updated Entries of Last 6 Months') selected="selected" @endif >First Page & Updated Entries of Last 6 Months</option>
						  </select>
					  </div>
					  <div class="col-md-12">
						<input type="file" id="borrower_bankdetail_file" name="borrower_bankdetail_file" value="{{$result->borrower_bankdetail_file}}" >
					  </div>
					</div>
				  </div>
				  <div class="col-md-4">
					<div class="row">
					  <div class="col-md-12 fileinput">
						<label class="control-label">Income Detail</label>
					  </div>
					  <div class="col-md-12">
						<select id="borrower_incomedetail" name="borrower_incomedetail" class="form-control select2">
							<option value="Salary Certificate" @if($result->borrower_incomedetail=='Salary Certificate') selected="selected" @endif >Salary Certificate</option>
							<option value="Income Tax Return" @if($result->borrower_incomedetail=='Income Tax Return') selected="selected" @endif >Income Tax Return</option>
						  </select>
					  </div>
					  <div class="col-md-12">
						<input type="file" id="borrower_incomedetail_file" name="borrower_incomedetail_file" value="{{$result->borrower_incomedetail_file}}" >
					  </div>
					</div>
				  </div>
				</div>
				</fieldset>
				<p>&nbsp;</p>
				<fieldset>
				<legend>References (Residing in the same area)</legend>
					<div class="row">
					  <div class="col-md-4">
						<div class="row">
						  <div class="col-md-12 fileinput">
							<label class="control-label">1. Name of Person</label>
						  </div>
						  <div class="col-md-12">
							<input type="text" class="form-control" id="borrower_reference_1_name" name="borrower_reference_1_name" value="{{$result->borrower_reference_1_name}}" >
						  </div>
						</div>
					  </div>
					  <div class="col-md-4">
						<div class="row">
						  <div class="col-md-12 fileinput">
							<label class="control-label">Relationship</label>
						  </div>
						  <div class="col-md-12">
							<input type="text" class="form-control" id="borrower_reference_1_relation" name="borrower_reference_1_relation" value="{{$result->borrower_reference_1_relation}}" >
						  </div>
						</div>
					  </div>
					  <div class="col-md-4">
						<div class="row">
						  <div class="col-md-12 fileinput">
							<label class="control-label">Address</label>
						  </div>
						  <div class="col-md-12">
							<input type="text" class="form-control" id="borrower_reference_1_addr" name="borrower_reference_1_addr" value="{{$result->borrower_reference_1_addr}}" >
						  </div>
						</div>
					  </div>
					</div>
					<div class="row">
					  <div class="col-md-12">
						<label class="control-label">Telephone No.</label>
					  </div>
					</div>
					<div class="row">
					  <div class="col-md-4">
						<div class="row">
						  <div class="col-md-12 fileinput">
							<label class="control-label">Office</label>
						  </div>
						  <div class="col-md-12">
							<input type="text" class="form-control" id="borrower_reference_1_phone_office" name="borrower_reference_1_phone_office" value="{{$result->borrower_reference_1_phone_office}}" >
						  </div>
						</div>
					  </div>
					  <div class="col-md-4">
						<div class="row">
						  <div class="col-md-12 fileinput">
							<label class="control-label">Residence</label>
						  </div>
						  <div class="col-md-12">
							<input type="text" class="form-control" id="borrower_reference_1_phone_residence" name="borrower_reference_1_phone_residence" value="{{$result->borrower_reference_1_phone_residence}}" >
						  </div>
						</div>
					  </div>
					  <div class="col-md-4">
						<div class="row">
						  <div class="col-md-12 fileinput">
							<label class="control-label">Mobile</label>
						  </div>
						  <div class="col-md-12">
							<input type="text" class="form-control" id="borrower_reference_1_phone_mobile" name="borrower_reference_1_phone_mobile" value="{{$result->borrower_reference_1_phone_mobile}}" >
						  </div>
						</div>
					  </div>
					</div>
					<p>&nbsp;</p>
					<div class="row">
					  <div class="col-md-4">
						<div class="row">
						  <div class="col-md-12 fileinput">
							<label class="control-label">2. Name of Person</label>
						  </div>
						  <div class="col-md-12">
							<input type="text" class="form-control" id="borrower_reference_2_name" name="borrower_reference_2_name" value="{{$result->borrower_reference_2_name}}" >
						  </div>
						</div>
					  </div>
					  <div class="col-md-4">
						<div class="row">
						  <div class="col-md-12 fileinput">
							<label class="control-label">Relationship</label>
						  </div>
						  <div class="col-md-12">
							<input type="text" class="form-control" id="borrower_reference_2_relation" name="borrower_reference_2_relation" value="{{$result->borrower_reference_2_relation}}" >
						  </div>
						</div>
					  </div>
					  <div class="col-md-4">
						<div class="row">
						  <div class="col-md-12 fileinput">
							<label class="control-label">Address</label>
						  </div>
						  <div class="col-md-12">
							<input type="text" class="form-control" id="borrower_reference_2_addr" name="borrower_reference_2_addr" value="{{$result->borrower_reference_2_addr}}" >
						  </div>
						</div>
					  </div>
					</div>
					<div class="row">
					  <div class="col-md-12">
						<label class="control-label">Telephone No.</label>
					  </div>
					</div>
					<div class="row">
					  <div class="col-md-4">
						<div class="row">
						  <div class="col-md-12 fileinput">
							<label class="control-label">Office</label>
						  </div>
						  <div class="col-md-12">
							<input type="text" class="form-control" id="borrower_reference_2_phone_office" name="borrower_reference_2_phone_office" value="{{$result->borrower_reference_2_phone_office}}" >
						  </div>
						</div>
					  </div>
					  <div class="col-md-4">
						<div class="row">
						  <div class="col-md-12 fileinput">
							<label class="control-label">Residence</label>
						  </div>
						  <div class="col-md-12">
							<input type="text" class="form-control" id="borrower_reference_2_phone_residence" name="borrower_reference_2_phone_residence" value="{{$result->borrower_reference_2_phone_residence}}" >
						  </div>
						</div>
					  </div>
					  <div class="col-md-4">
						<div class="row">
						  <div class="col-md-12 fileinput">
							<label class="control-label">Mobile</label>
						  </div>
						  <div class="col-md-12">
							<input type="text" class="form-control" id="borrower_reference_2_phone_mobile" name="borrower_reference_2_phone_mobile" value="{{$result->borrower_reference_2_phone_mobile}}" >
						  </div>
						</div>
					  </div>
					</div>
				</fieldset>
			  </div>
          </fieldset>
		  <p>&nbsp;</p>
		  <fieldset>
			  <legend>Co-Borrower Details</legend>
			  <div class="row">
				<div class="col-md-4">
				  <div class="row">
					<div class="col-md-12">
					  <label class="control-label">Name of Co-Borrower<span class="required">*</span></label>
					</div>
					<div class="col-md-12">
					  <input type="text" id="co_borrower_name" name="co_borrower_name" value="{{$result->co_borrower_name}}" class="form-control">
					</div>
				  </div>
				</div>
				<div class="col-md-2">
				  <div class="row">
					<div class="col-md-12">
					  <label class="control-label">Age <span class="required">*</span></label>
					</div>
					<div class="col-md-12">
					  <input type="text" id="co_borrower_age" name="co_borrower_age" value="{{$result->co_borrower_age}}" class="form-control">
					</div>
				  </div>
				</div>
				<div class="col-md-3">
				  <div class="row">
					<div class="col-md-12">
					  <label class="control-label">Father's / Husband Name Shri<span class="required">*</span></label>
					</div>
					<div class="col-md-12">
					  <select id="co_borrower_care_of" name="co_borrower_care_of" class="form-control select2">
						<option value="Father" @if($result->co_borrower_care_of=='Father') selected="selected" @endif >Father</option>
						<option value="Husband" @if($result->co_borrower_care_of=='Husband') selected="selected" @endif >Husband</option>
					  </select>
					</div>
				  </div>
				</div>
				<div class="col-md-3">
				  <div class="row">
					<div class="col-md-12">
					  <label class="control-label">&nbsp;</label>
					</div>
					<div class="col-md-12">
					  <input type="text" id="co_borrower_care_of_name" name="co_borrower_care_of_name" value="{{$result->co_borrower_care_of_name}}" class="form-control">
					</div>
				  </div>
				</div>
			  </div>
			  <div class="row">
				<div class="col-md-6">
				  <div class="row">
					<div class="col-md-12">
					  <label class="control-label">Present Address <span class="required">*</span></label>
					</div>
					<div class="col-md-12">
					  <textarea name="co_borrower_present_addr" id="co_borrower_present_addr" class="form-control">{{ $result->co_borrower_present_addr}} </textarea>
					</div>
				  </div>
				</div>
				<div class="col-md-6">
				  <div class="row">
					<div class="col-md-12">
					  <label class="control-label">Land Mark <span class="required">*</span></label>
					</div>
					<div class="col-md-12">
					  <textarea name="co_borrower_present_addr_ladmark" id="co_borrower_present_addr_ladmark" class="form-control">{{ $result->co_borrower_present_addr_ladmark}} </textarea>
					</div>
				  </div>
				</div>
			  </div>
			  <div class="row">
				<div class="col-md-6">
				  <div class="row">
					<div class="col-md-12">
					  <label class="control-label">Permanent Home Address <span class="required">*</span></label>
					</div>
					<div class="col-md-12">
					  <textarea name="co_borrower_parmanent_addr" id="co_borrower_parmanent_addr" class="form-control">{{ $result->co_borrower_parmanent_addr}} </textarea>
					</div>
				  </div>
				</div>
				<div class="col-md-6">
				  <div class="row">
					<div class="col-md-12">
					  <label class="control-label">Residence <span class="required">*</span></label>
					</div>
					<div class="col-md-12">
						<div class="row">
							<div class="col-md-6">
								Own <input type="radio"  name="co_borrower_present_addr_type" value="Own">
							</div>
							<div class="col-md-6">
								Rental <input type="radio"  name="co_borrower_present_addr_type" value="Rental">
							</div>
						</div>
					    <div class="row">
							<div class="col-md-6">
								Parent/Spouse <input type="radio"  name="co_borrower_present_addr_type" value="Parent/Spouse" >
							</div>
							<div class="col-md-6">
								Employer Leased <input type="radio"  name="co_borrower_present_addr_type" value="Employer Leased">
							</div>
						</div>
					</div>
				  </div>
				</div>
			  </div>
			  <div class="row">
				<div class="col-md-6">
				  <div class="row">
					<div class="col-md-12">
					  <label class="control-label">Occupation <span class="required">*</span></label>
					</div>
					<div class="col-md-12">
					  <input type="text" id="co_borrower_occupation" name="co_borrower_occupation" value="{{$result->co_borrower_occupation}}" class="form-control">
					</div>
				  </div>
				  <div class="row">
					<div class="col-md-12">
					  <label class="control-label">Designation <span class="required">*</span></label>
					</div>
					<div class="col-md-12">
					  <input type="text" id="co_borrower_designation" name="co_borrower_designation" value="{{$result->co_borrower_designation}}" class="form-control">
					</div>
				  </div>
				</div>
				<div class="col-md-6">
				  <div class="row">
					<div class="col-md-12">
					  <label class="control-label">Name & Office Address/Plase of Business <span class="required">*</span></label>
					</div>
					<div class="col-md-12">
					  <textarea name="co_borrower_office_addr" id="co_borrower_office_addr" class="form-control">{{ $result->co_borrower_office_addr}} </textarea>
					</div>
				  </div>
				</div>
			  </div>
			  <div class="row">
			    <div class="col-md-12">
			    	<label class="control-label">Telephone No. <span class="required">*</span></label>
				</div>
				<div class="col-md-4">
				  <div class="row">
					<div class="col-md-12">
					  <label class="control-label">Office <span class="required">*</span></label>
					</div>
					<div class="col-md-12">
					  <input type="text" id="co_borrower_phone_office" name="co_borrower_phone_office" value="{{$result->co_borrower_phone_office}}" class="form-control">
					</div>
				  </div>
				</div>
				<div class="col-md-4">
				  <div class="row">
					<div class="col-md-12">
					  <label class="control-label">Residence <span class="required">*</span></label>
					</div>
					<div class="col-md-12">
					  <input type="text" id="co_borrower_phone_residence" name="co_borrower_phone_residence" value="{{$result->co_borrower_phone_residence}}" class="form-control">
					</div>
				  </div>
				</div>
				<div class="col-md-4">
				  <div class="row">
					<div class="col-md-12">
					  <label class="control-label">Mobile <span class="required">*</span></label>
					</div>
					<div class="col-md-12">
					  <input type="text" id="co_borrower_phone_mobile" name="co_borrower_phone_mobile" value="{{$result->co_borrower_phone_mobile}}" class="form-control">
					</div>
				  </div>
				</div>
			  </div>
          </fieldset>
		  <p>&nbsp;</p>
		  <fieldset>
			  <legend>Guarantor Details</legend>
			  <div class="row">
				<div class="col-md-4">
				  <div class="row">
					<div class="col-md-12">
					  <label class="control-label">Name of Guarantor<span class="required">*</span></label>
					</div>
					<div class="col-md-12">
					  <input type="text" id="guarantor_name" name="guarantor_name" value="{{$result->guarantor_name}}" class="form-control">
					</div>
				  </div>
				</div>
				<div class="col-md-2">
				  <div class="row">
					<div class="col-md-12">
					  <label class="control-label">Age <span class="required">*</span></label>
					</div>
					<div class="col-md-12">
					  <input type="text" id="guarantor_age" name="guarantor_age" value="{{$result->guarantor_age}}" class="form-control">
					</div>
				  </div>
				</div>
				<div class="col-md-3">
				  <div class="row">
					<div class="col-md-12">
					  <label class="control-label">Father's / Husband Name Shri<span class="required">*</span></label>
					</div>
					<div class="col-md-12">
					  <select id="guarantor_care_of" name="guarantor_care_of" class="form-control select2">
						<option value="Father" @if($result->guarantor_care_of=='Father') selected="selected" @endif >Father</option>
						<option value="Husband" @if($result->guarantor_care_of=='Husband') selected="selected" @endif >Husband</option>
					  </select>
					</div>
				  </div>
				</div>
				<div class="col-md-3">
				  <div class="row">
					<div class="col-md-12">
					  <label class="control-label">&nbsp;</label>
					</div>
					<div class="col-md-12">
					  <input type="text" id="guarantor_care_of_name" name="guarantor_care_of_name" value="{{$result->guarantor_care_of_name}}" class="form-control">
					</div>
				  </div>
				</div>
			  </div>
			  <div class="row">
				<div class="col-md-6">
				  <div class="row">
					<div class="col-md-12">
					  <label class="control-label">Present Address <span class="required">*</span></label>
					</div>
					<div class="col-md-12">
					  <textarea name="guarantor_present_addr" id="guarantor_present_addr" class="form-control">{{ $result->guarantor_present_addr}} </textarea>
					</div>
				  </div>
				</div>
				<div class="col-md-6">
				  <div class="row">
					<div class="col-md-12">
					  <label class="control-label">Land Mark <span class="required">*</span></label>
					</div>
					<div class="col-md-12">
					  <textarea name="guarantor_present_addr_ladmark" id="guarantor_present_addr_ladmark" class="form-control">{{ $result->guarantor_present_addr_ladmark}} </textarea>
					</div>
				  </div>
				</div>
			  </div>
			  <div class="row">
				<div class="col-md-6">
				  <div class="row">
					<div class="col-md-12">
					  <label class="control-label">Permanent Home Address <span class="required">*</span></label>
					</div>
					<div class="col-md-12">
					  <textarea name="guarantor_parmanent_addr" id="guarantor_parmanent_addr" class="form-control">{{ $result->guarantor_parmanent_addr}} </textarea>
					</div>
				  </div>
				</div>
				<div class="col-md-6">
				  <div class="row">
					<div class="col-md-12">
					  <label class="control-label">Residence <span class="required">*</span></label>
					</div>
					<div class="col-md-12">
						<div class="row">
							<div class="col-md-6">
								Own <input type="radio"  name="guarantor_present_addr_type" value="Own">
							</div>
							<div class="col-md-6">
								Rental <input type="radio"  name="guarantor_present_addr_type" value="Rental">
							</div>
						</div>
					    <div class="row">
							<div class="col-md-6">
								Parent/Spouse <input type="radio"  name="guarantor_present_addr_type" value="Parent/Spouse" >
							</div>
							<div class="col-md-6">
								Employer Leased <input type="radio"  name="guarantor_present_addr_type" value="Employer Leased">
							</div>
						</div>
					</div>
				  </div>
				</div>
			  </div>
			  <div class="row">
				<div class="col-md-6">
				  <div class="row">
					<div class="col-md-12">
					  <label class="control-label">Occupation <span class="required">*</span></label>
					</div>
					<div class="col-md-12">
					  <input type="text" id="guarantor_occupation" name="guarantor_occupation" value="{{$result->guarantor_occupation}}" class="form-control">
					</div>
				  </div>
				  <div class="row">
					<div class="col-md-12">
					  <label class="control-label">Designation <span class="required">*</span></label>
					</div>
					<div class="col-md-12">
					  <input type="text" id="guarantor_designation" name="guarantor_designation" value="{{$result->guarantor_designation}}" class="form-control">
					</div>
				  </div>
				</div>
				<div class="col-md-6">
				  <div class="row">
					<div class="col-md-12">
					  <label class="control-label">Name & Office Address/Plase of Business <span class="required">*</span></label>
					</div>
					<div class="col-md-12">
					  <textarea name="guarantor_office_addr" id="guarantor_office_addr" class="form-control">{{ $result->guarantor_office_addr}} </textarea>
					</div>
				  </div>
				</div>
			  </div>
			  <div class="row">
			    <div class="col-md-12">
			    	<label class="control-label">Telephone No. <span class="required">*</span></label>
				</div>
				<div class="col-md-4">
				  <div class="row">
					<div class="col-md-12">
					  <label class="control-label">Office <span class="required">*</span></label>
					</div>
					<div class="col-md-12">
					  <input type="text" id="guarantor_phone_office" name="guarantor_phone_office" value="{{$result->guarantor_phone_office}}" class="form-control">
					</div>
				  </div>
				</div>
				<div class="col-md-4">
				  <div class="row">
					<div class="col-md-12">
					  <label class="control-label">Residence <span class="required">*</span></label>
					</div>
					<div class="col-md-12">
					  <input type="text" id="guarantor_phone_residence" name="guarantor_phone_residence" value="{{$result->guarantor_phone_residence}}" class="form-control">
					</div>
				  </div>
				</div>
				<div class="col-md-4">
				  <div class="row">
					<div class="col-md-12">
					  <label class="control-label">Mobile <span class="required">*</span></label>
					</div>
					<div class="col-md-12">
					  <input type="text" id="guarantor_phone_mobile" name="guarantor_phone_mobile" value="{{$result->guarantor_phone_mobile}}" class="form-control">
					</div>
				  </div>
				</div>
			  </div>
			  <div class="row">
				<div class="col-md-4">
				  <div class="row">
					<div class="col-md-12">
					  <label class="control-label">Is the Post Permanent or Temporary</label>
					</div>
					<div class="col-md-12">
					  <select id="guarantor_job_type" name="guarantor_job_type" class="form-control select2">
						<option value="Permanent" @if($result->guarantor_job_type=='Father') selected="selected" @endif >Permanent</option>
						<option value="Temporary" @if($result->guarantor_job_type=='Temporary') selected="selected" @endif >Temporary</option>
					  </select>
					</div>
				  </div>
				</div>
				<div class="col-md-4">
				  <div class="row">
					<div class="col-md-12">
					  <label class="control-label">Whether your occupation is subject to transfer</label>
					</div>
					<div class="col-md-12">
					  <input type="text" id="guarantor_occupation_transfer" name="guarantor_occupation_transfer" value="{{$result->guarantor_occupation_transfer}}" class="form-control">
					</div>
				  </div>
				</div>
				<div class="col-md-4">
				  <div class="row">
					<div class="col-md-12">
					  <label class="control-label">Gross Family Income</label>
					</div>
					<div class="col-md-12">
					  <input type="text" id="guarantor_family_income" name="guarantor_family_income" value="{{$result->guarantor_family_income}}" class="form-control">
					</div>
				  </div>
				</div>
			  </div>
			  <div class="innerlegend">
            	<fieldset>
				<legend>Attach Photocopy</legend>
				<div class="row">
				  <div class="col-md-4">
					<div class="row">
					  <div class="col-md-12 fileinput">
						<label class="control-label">Identity Details</label>
					  </div>
					  <div class="col-md-12">
						<select id="guarantor_identity" name="guarantor_identity" class="form-control select2">
							<option value="Voter Card" @if($result->guarantor_identity=='Voter Card') selected="selected" @endif >Voter Card</option>
							<option value="Ration Card" @if($result->guarantor_identity=='Ration Card') selected="selected" @endif >Ration Card</option>
							<option value="Electricity Bill" @if($result->guarantor_identity=='Electricity Bill') selected="selected" @endif >Electricity Bill</option>
							<option value="Water Tax Receipt" @if($result->guarantor_identity=='Water Tax Receipt') selected="selected" @endif >Water Tax Receipt</option>
						  </select>
					  </div>
					  <div class="col-md-12">
						<input type="file" id="guarantor_identity_file" name="guarantor_identity_file" value="{{$result->guarantor_identity_file}}" >
					  </div>
					</div>
				  </div>
				  <div class="col-md-4">
					<div class="row">
					  <div class="col-md-12 fileinput">
						<label class="control-label"> Bank Detail</label>
					  </div>
					  <div class="col-md-12">
						<select id="guarantor_bankdetail" name="guarantor_bankdetail" class="form-control select2">
							<option value="Photocopy of Latest Bank Statement" @if($result->guarantor_bankdetail=='Photocopy of Latest Bank Statement') selected="selected" @endif >Photocopy of Latest Bank Statement</option>
							<option value="First Page & Updated Entries of Last 6 Months" @if($result->guarantor_bankdetail=='First Page & Updated Entries of Last 6 Months') selected="selected" @endif >First Page & Updated Entries of Last 6 Months</option>
						  </select>
					  </div>
					  <div class="col-md-12">
						<input type="file" id="guarantor_bankdetail_file" name="guarantor_bankdetail_file" value="{{$result->guarantor_bankdetail_file}}" >
					  </div>
					</div>
				  </div>
				  <div class="col-md-4">
					<div class="row">
					  <div class="col-md-12 fileinput">
						<label class="control-label">Income Detail</label>
					  </div>
					  <div class="col-md-12">
						<select id="guarantor_incomedetail" name="guarantor_incomedetail" class="form-control select2">
							<option value="Salary Certificate" @if($result->guarantor_incomedetail=='Salary Certificate') selected="selected" @endif >Salary Certificate</option>
							<option value="Income Tax Return" @if($result->guarantor_incomedetail=='Income Tax Return') selected="selected" @endif >Income Tax Return</option>
						  </select>
					  </div>
					  <div class="col-md-12">
						<input type="file" id="guarantor_incomedetail_file" name="guarantor_incomedetail_file" value="{{$result->guarantor_incomedetail_file}}" >
					  </div>
					</div>
				  </div>
				</div>
				</fieldset>
			  </div>
          </fieldset>
		  
        </div>
        
        <input type="submit" class="btn btn-success" name="submit">
      </form>
    </div>
  </div>
</div>
@endsection 

@section('script')
<script type="text/javascript">
	$('.cal').Zebra_DatePicker();
	$(document).ready(function() {
		$(".select2").select2();
	});
</script>
@endsection 